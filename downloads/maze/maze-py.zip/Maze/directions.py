import random

def find_direction_tile(towards, direction, tile, rows):
    if direction == 'East':
            if towards == True:
                    return tile + 1
            else:
                return tile - 1
    elif direction == 'West':
            if towards == True:
                    return tile - 1
            else:
                return tile + 1
    elif direction == 'North':
            if towards == True:
                    return tile - rows
            else:
                return tile + rows
    elif direction == 'South':
            if towards == True:
                    return tile + rows
            else:
                return tile - rows
            
def find_new_dir(tile, remaining_list):
  dir = 0
  new_list = []
  randint = random.randint(1, len(remaining_list))
  print('LIST', tile, remaining_list, randint)
  if randint == 1:
    if (tile + 1) % 30 != 0:
      dir = 'West'
    else:
      new_list.append('West')
  if randint == 2:
    if tile % 30 != 0:
      dir = 'East'
    else:
      print('NEW', new_list, remaining_list.remove('East'))
      new_list.append('East')
  if randint == 3:
    if tile < 870:
      dir = 'South'
    else:
      print('NEW', new_list, remaining_list.remove('South'))
      new_list.append('South')
  if randint == 4:
    if tile > 30:
      dir = 'North'
    else:
      print('NEW', new_list, remaining_list.remove('North'))
      new_list.append('North')
  if dir == 0:
    return dir
  else:
    find_new_dir(tile, new_list)
  