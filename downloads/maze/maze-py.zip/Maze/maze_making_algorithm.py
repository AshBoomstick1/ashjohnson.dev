#makes maze for maze solving algorithim

import datetime
import time
import random

rows = 20
cols = 20

tile_list = ['\x1B[100m  \x1B[0m' for tile in range(0, rows * cols)]

empty_list = [0]
dead_end_marker_list = []

def print_whole_board(special_tile = 0, second_special = 0, new_tile = 0):
  tile_list[0] = "00"
  for tile in nodes_list: tile_list[tile] = '\x1B[103m  \x1B[0m'
  for tile in empty_list: tile_list[tile] = '\x1B[0m  \x1B[0m'
  #for tile in dead_end_marker_list: tile_list[tile] = '\x1B[101m  \x1B[0m'
  tile_list[special_tile] = '\x1B[0mNT\x1B[0m'
  tile_list[second_special] = '\x1B[0mST\x1B[0m'
  tile_list[new_tile] = '\x1B[0mOT\x1B[0m'

  return_first_row = ''
  for col in range(cols + 2):
    return_first_row += '  '
  print('\x1B[107m' + return_first_row + '\x1B[0m')
  def print_board(tile_count, row_count):
    return_string = ''
    if row_count < rows:
      for col in range(cols):
        tile_count += 1
        return_string += tile_list[tile_count - 1]
      print('\x1B[107m  \x1B[0m' + return_string + '\x1B[107m  \x1B[0m')
      print_board(tile_count, row_count + 1)
  print_board(0, 0)
  print('\x1B[107m' + return_first_row + '\x1B[0m')
nodes_list = []
for row in range(0, rows):
  if row % 2 == 0:
    for tile in range(row * cols, (row * cols) + cols):
      if tile == 0 or tile % 2 == 0:
        nodes_list.append(tile)



def find_new_intersection(tile, last_tile):
  time.sleep(0.04)
  if len(nodes_list) - 2 == len(dead_end_marker_list): return
  if (tile - 1) in empty_list and (tile - 2) != last_tile and (tile - 2) not in dead_end_marker_list:
    new_tile = tile - 2
  elif (tile + 1) in empty_list and (tile + 2) != last_tile and (tile + 2) not in dead_end_marker_list:
    new_tile = tile + 2
  elif (tile + cols) in empty_list and (tile + (cols * 2)) != last_tile and (tile + (cols * 2)) not in dead_end_marker_list:
    new_tile = tile + (cols * 2)
  elif (tile - cols) in empty_list and (tile - (cols * 2)) != last_tile and (tile - (cols * 2)) not in dead_end_marker_list:
    new_tile = tile - (cols * 2)

  is_free = 0
  if new_tile % 30 != 0 and (new_tile - 2) not in empty_list: is_free += 1
  if (new_tile + 2) % 30 != 0 and (new_tile + 2) not in empty_list: is_free += 1
  if new_tile < (rows * cols) - (cols * 2) and (new_tile + (cols * 2)) not in empty_list: is_free += 1
  if new_tile > cols - 1 and (new_tile - (cols * 2)) not in empty_list: is_free += 1

  nearby_paths = 0
  if (new_tile - 1) in empty_list: nearby_paths += 1
  if (new_tile + 1) in empty_list: nearby_paths += 1
  if (new_tile + cols) in empty_list: nearby_paths += 1
  if (new_tile - cols) in empty_list: nearby_paths += 1

  if nearby_paths > 1:
    dead_end_marker_list.append(tile)
  print_whole_board(new_tile, tile, last_tile)

  if is_free > 0: 
    return int(new_tile)
  else:
    return find_new_intersection(new_tile, tile)
  

def find_next_tile(tile):
  time.sleep(0.04)
  if len(nodes_list) - 2 == len(dead_end_marker_list): return
  available_turn_list = []
  available_tile_list = []
  if tile % cols != 0 and (tile - 2) not in empty_list:
    available_turn_list.append(tile - 1)
    available_tile_list.append(tile - 2)
  if (tile + 2) % cols != 0 and (tile + 2) not in empty_list:
    available_turn_list.append(tile + 1)
    available_tile_list.append(tile + 2)
  if tile < (rows * cols) - (cols * 2) and (tile + (cols * 2)) not in empty_list:
    available_turn_list.append(tile + cols)
    available_tile_list.append(tile + (cols * 2))
  if tile > cols + 1 and (tile - (cols * 2)) not in empty_list:
    available_turn_list.append(tile - cols)
    available_tile_list.append(tile - (cols * 2))
  if len(available_turn_list) > 1 and tile != (rows * cols) - cols - 2:
    rand_idx = random.randint(0, len(available_turn_list) - 1)
    empty_list.append(available_turn_list[rand_idx])
    empty_list.append(available_tile_list[rand_idx])
    print_whole_board()
    find_next_tile(empty_list[-1])
  elif len(available_tile_list) == 1 and tile != (rows * cols) - cols - 2:
    if available_tile_list[0] not in empty_list:
      empty_list.append(available_turn_list[0])
      empty_list.append(available_tile_list[0])
      print_whole_board()
      find_next_tile(empty_list[-1])
  elif len(available_tile_list) == 0 or tile == (rows * cols) - cols - 2:
    new_junction_tile = find_new_intersection(tile, tile)
    find_next_tile(new_junction_tile)


def make_maze():
  global dead_end_marker_list
  global empty_list
  empty_list = []
  start_time = datetime.datetime.now()
  dead_end_marker_list = []
  tile_list = ['\x1B[100m  \x1B[0m' for tile in range(0, rows * cols)]
  find_next_tile(0)
  endtime = datetime.datetime.now()
  return [tile_list, empty_list]



print_whole_board()

make_maze()
