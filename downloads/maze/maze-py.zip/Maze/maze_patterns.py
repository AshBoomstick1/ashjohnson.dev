from maze_solving_algorithm import solve_maze
from random import randrange, shuffle
import datetime
import time

start_time = datetime.datetime.now()

rows = 20
cols = 20

def print_whole_board(tile_list, empty_list, visited_list):
  for tile in empty_list: tile_list[tile] = '\x1B[0m  \x1B[0m'
  for tile in visited_list: tile_list[tile] = '\x1B[105m  \x1B[0m'
  return_first_row = ''
  for col in range(cols + 2):
    return_first_row += '  '
  print('\x1B[107m' + return_first_row + '\x1B[0m')
  def print_board(tile_count, row_count):
    return_string = ''
    if row_count < rows:
      for col in range(cols):
        tile_count += 1
        return_string += tile_list[tile_count - 1]
      print('\x1B[107m  \x1B[0m' + return_string + '\x1B[107m  \x1B[0m')
      print_board(tile_count, row_count + 1)
  print_board(0, 0)
  print('\x1B[107m' + return_first_row + '\x1B[0m')
  

mazes = {}

for i in range(0, 10):
  print(i)
  mazes[i] = solve_maze()

def quicksort(list, start, end):
  if start >= end:
    return
  pivot_idx = randrange(start, end + 1)
  pivot_element = list[pivot_idx]
  list[end], list[pivot_idx] = list[pivot_idx], list[end]
  less_than_pointer = start
  
  for i in range(start, end):
    if list[i] < pivot_element:
      list[i], list[less_than_pointer] = list[less_than_pointer], list[i]
      less_than_pointer += 1
  list[end], list[less_than_pointer] = list[less_than_pointer], list[end]
  quicksort(list, start, less_than_pointer - 1)
  quicksort(list, less_than_pointer + 1, end)


keys = list(mazes.keys())

quicksort(mazes, 0, len(mazes) - 1)

#[tile_list, len(visited_list) + len(dead_end_marker_list) * 2, empty_list, visited_list, str(end_time - start_time)]

print(mazes[keys[0]][1])
tile_list1 = mazes[keys[0]][0]
empty_list1 = mazes[keys[0]][2]
visited_list1 = mazes[keys[0]][3]
print_whole_board(tile_list1, empty_list1, visited_list1)
print(mazes[keys[len(keys)//2]][1])

tile_list2 = mazes[keys[len(keys)//2]][0]
empty_list2 = mazes[keys[len(keys)//2]][2]
visited_list2 = mazes[keys[len(keys)//2]][3]
print_whole_board(tile_list2, empty_list2, visited_list2)

print(mazes[keys[len(keys)-1]][1])
tile_list3 = mazes[keys[len(keys)-1]][0]
empty_list3 = mazes[keys[len(keys)-1]][2]
visited_list3 = mazes[keys[len(keys)-1]][3]
print_whole_board(tile_list3, empty_list3, visited_list3)

end_time = datetime.datetime.now()

print("TIME: ", str(end_time - start_time))

#input = input("WATCH MAZE SOLVE?(1, 2, 3)")

"""
if input == str(1): replay_maze(mazes[keys[0]])
if input == str(2): replay_maze(mazes[keys[len(keys)//2]])
if input == str(3): replay_maze(mazes[keys[len(keys)-1]])
"""
