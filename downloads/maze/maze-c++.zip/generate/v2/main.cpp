#include "making.hpp"

//compiling command linux:  clear && g++ -std=c++11 ./../../../errorLog/errorlog.cpp ./../../../basicTerminalDisplay/display.cpp main.cpp -o maze_generatorUnix && ./maze_generatorUnix

#include <vector>
#include <string>
#include <algorithm>
#include <iostream>

//rows and cols must be odd
int rows = 11;
int cols = 11;

const bool skip_some_graphics = true;

const int delay = 50;

std::vector<int> last_intersection = {};

std::vector<std::string> map = {};
std::string title = "Maze Generator";
std::vector<std::vector<int>> pos_data;
std::vector<std::string> info_data;
std::vector<std::vector<int>> path_list = {{0, 0}};
std::vector<std::vector<int>> dead_ends = {};

std::vector<std::vector<int>>* pPos = &pos_data;
std::vector<std::string>* pInfo = &info_data;

const std::string empty_tile = "  ";
std::string possible_tile_color = "\x1B[101m  \x1B[0m";
std::string path_color = "\x1B[102m  \x1B[0m";
std::string border_color = "\x1B[100m  \x1B[0m";
std::string current_tile_color = "\x1B[105m  \x1B[0m";
std::string dead_tile_color = "\x1B[103m  \x1B[0m";

std::string* ptrPossible = &possible_tile_color;
std::string* ptrPath     = &path_color;
std::string* ptrBorder   = &border_color;
std::string* ptrCurrent  = &current_tile_color;
std::string* ptrDead     = &dead_tile_color;



bool search_coord_vec(const int &x, const int &y, std::vector<std::vector<int>> vec)
{
  //std::cout << "HERE WE GO:\n";
  for (int i = 0; i < vec.size(); i++)
  {
    //std::cout << "\tVEC: (" << vec[i][0] << ", " << vec[i][1] << ") === (" << x << ", " << y << ")\n";
    if (vec[i][0] == x && vec[i][1] == y)
    {
      //std::cout << "\tMADE IT!\n";
      return true;
    }
  }
  return false;
}

bool available_tile(int x, int y)
{
  if (search_coord_vec(x, y, path_list) == false && search_coord_vec(x, y, dead_ends) == false)
  {
    if (x >= 0 && x <= cols - 1)
    {
      if (y >= 0 && y <= rows - 1)
      {
        return true;
      }
    }
  }
  return false;
}


void find_new_intersection(int currentX, int currentY, int oldX, int oldY)
{
  /*
    PLAN for optimization:

    have the new_tile func make a list of every possible intersection it comes across.
    this functioin on fast mode will skip all of this code here and only check the possible intersections
    it will make sure the intersection have at least one free tile,. then run the new_tile function with the possibler_intersection coords
    then it will remove the selected possible intersection and all the failed ones from the list of possible intersections.
  
  */
  std::vector<int> temp_pos;

  if (!skip_some_graphics)
  {
    temp_pos = {oldX, oldY};
    print_single_pixel(cols, rows, temp_pos, *ptrPath, 0);
  }

  std::string empty = "";


  std::vector<std::vector<int>> possible_tiles = {}; //nearby path tiles
  std::vector<std::vector<int>> empty_tiles = {}; //nearby empty tiles

  //possible
  if (available_tile(currentX - 1, currentY) == false && available_tile(currentX - 2, currentY) == false && currentX - 1 >= 0) //check left
  {
    possible_tiles.push_back({currentX - 2, currentY}); //adds the coordinates to available tiles
  }

  if (available_tile(currentX + 1, currentY) == false && available_tile(currentX + 2, currentY) == false && currentX + 1 <= cols - 1) //check right
  {
    possible_tiles.push_back({currentX + 2, currentY});
  }

  if (available_tile(currentX, currentY + 1) == false && available_tile(currentX, currentY + 2) == false && currentY + 1 <= rows - 1) //check up
  {
    possible_tiles.push_back({currentX, currentY + 2});
  }

  if (available_tile(currentX, currentY - 1) == false && available_tile(currentX, currentY - 2) == false && currentY - 1 >= 0) //check down
  {
    possible_tiles.push_back({currentX, currentY - 2});
  }



  //empty
  if (available_tile(currentX - 1, currentY) == true && available_tile(currentX - 2, currentY) == true && currentX - 1 >= 0) //check left
  {
    empty_tiles.push_back({currentX - 2, currentY}); //adds the coordinates to available tiles
  }

  if (available_tile(currentX + 1, currentY) == true && available_tile(currentX + 2, currentY) == true && currentX + 1 <= cols - 1) //check right
  {
    empty_tiles.push_back({currentX + 2, currentY});
  }

  if (available_tile(currentX, currentY + 1) == true && available_tile(currentX, currentY + 2) == true && currentY + 1 <= rows - 1) //check up
  {
    empty_tiles.push_back({currentX, currentY + 2});
  }

  if (available_tile(currentX, currentY - 1) == true && available_tile(currentX, currentY - 2) == true && currentY - 1 >= 0) //check down
  {
    empty_tiles.push_back({currentX, currentY - 2});
  }

  if (currentX == 0 && currentY == 0 && path_list.size() > cols + rows)
  {
  }
  else if (empty_tiles.size() == 0)
  {
    if (possible_tiles.size() == 1)
    {

      if (!skip_some_graphics)
      {
        temp_pos = {(oldX + currentX) / 2, (oldY + currentY) / 2};
        print_single_pixel(cols, rows, temp_pos, *ptrCurrent, delay);

        temp_pos = {(oldX + currentX) / 2, (oldY + currentY) / 2};
        print_single_pixel(cols, rows, temp_pos, *ptrPath, 0);

        temp_pos = {currentX, currentY};
        print_single_pixel(cols, rows, temp_pos, *ptrCurrent, delay);
      }

      find_new_intersection(possible_tiles[0][0], possible_tiles[0][1], currentX, currentY);
    }
    else
    {
    for (int i = 0; i < possible_tiles.size(); i++)
    {
      if (search_coord_vec(possible_tiles[i][0], possible_tiles[i][1], dead_ends) == false && (possible_tiles[i][0] != oldX || possible_tiles[i][1] != oldY))
      {
        //replace_data(*pPos, *pInfo, (oldX + currentX) / 2, (oldY + currentY) / 2, *ptrCurrent);
        //printFrameWithBorder(cols, rows, *pPos, *pInfo, empty, *ptrBorder, delay);
        //replace_data(*pPos, *pInfo, (oldX + currentX) / 2, (oldY + currentY) / 2, *ptrPath);

        //replace_data(*pPos, *pInfo, currentX, currentY, *ptrCurrent);
        //printFrameWithBorder(cols, rows, *pPos, *pInfo, empty, *ptrBorder, delay);
        //replace_data(*pPos, *pInfo, currentX, currentY, *ptrPath);

        if (!skip_some_graphics)
        {
          temp_pos = {(oldX + currentX) / 2, (oldY + currentY) / 2};
          print_single_pixel(cols, rows, temp_pos, *ptrCurrent, delay);

          temp_pos = {(oldX + currentX) / 2, (oldY + currentY) / 2};
          print_single_pixel(cols, rows, temp_pos, *ptrPath, 0);

          temp_pos = {currentX, currentY};
          print_single_pixel(cols, rows, temp_pos, *ptrCurrent, delay);
        }
        
        find_new_intersection(possible_tiles[i][0], possible_tiles[i][1], currentX, currentY);
        i = possible_tiles.size();
      }
    }
    }
  }
  else if (empty_tiles.size() == 1)
  {
    replace_data(*pPos, *pInfo, (currentX + oldX) / 2, (currentY + oldY) / 2, *ptrDead);
    dead_ends.push_back({oldX, oldY});
    new_tile(currentX, currentY);
  }
  else if (empty_tiles.size() == 2)
  {
    replace_data(*pPos, *pInfo, (currentX + oldX) / 2, (currentY + oldY) / 2, *ptrDead);
    dead_ends.push_back({oldX, oldY});

    if (rand() % 2 == 0)
    {
      new_tile(currentX, currentY);
    }
    else
    {
      new_tile(currentX, currentY);
    }
  }
}


void new_tile(int currentX, int currentY) //finds the next tile in the maze
{

  std::string empty = "";


  std::vector<std::vector<int>> available_tiles = {}; //finds every horizontally or vertically adjacent tile that is not occupied {{x, y}, {x, y}}
  std::vector<std::vector<int>> between_tiles = {}; //every tile inbetween each available tile and the current tile

  //finds and fills available tiles & between tiles
  if (available_tile(currentX - 2, currentY)) //check left
  {
    available_tiles.push_back({currentX - 2, currentY}); //adds the coordinates to available tiles
    between_tiles.push_back({currentX - 1, currentY}); //adds the coordinates to between tiles
  }

  if (available_tile(currentX + 2, currentY)) //check right
  {
    available_tiles.push_back({currentX + 2, currentY});
    between_tiles.push_back({currentX + 1, currentY});
  }

  if (available_tile(currentX, currentY + 2)) //check up
  {
    available_tiles.push_back({currentX, currentY + 2});
    between_tiles.push_back({currentX, currentY + 1});
  }

  if (available_tile(currentX, currentY - 2)) //check down
  {
    available_tiles.push_back({currentX, currentY - 2});
    between_tiles.push_back({currentX, currentY - 1});
  }


  //finds a random number that coordisponds to the idx of an available tile in the available tiles list;
  int rand_int;

  if (available_tiles.size() == 0)
  {
    rand_int = 4;
  }
  else
  {
    rand_int = rand() % available_tiles.size();
  }

  if (available_tiles.size() > 1)
  {
    last_intersection = {currentX, currentY, 0, 0};
  }

  std::vector<int> temp_pos;

  switch (rand_int)
  {
  case 0:
    path_list.push_back(available_tiles[0]); //adds the chosen available tile to the path list
    path_list.push_back(between_tiles[0]); //adds the inbetween tile, is only important for printing and preserving matching idx between path list and posData
    insert_data(*pPos, *pInfo, between_tiles[0][0], between_tiles[0][1], *ptrPath); //adds the between tile to be printed

    temp_pos = {(currentX + available_tiles[0][0]) / 2, (currentY + available_tiles[0][1]) / 2};
    print_single_pixel(cols, rows, temp_pos, *ptrPath, delay);

    temp_pos = {available_tiles[0][0], available_tiles[0][1]};
    print_single_pixel(cols, rows, temp_pos, *ptrPath, delay);

    last_intersection[2] = available_tiles[0][0];
    last_intersection[3] = available_tiles[0][1];

    new_tile(available_tiles[0][0], available_tiles[0][1]);
    break;
  
  case 1:
    path_list.push_back(available_tiles[1]);
    path_list.push_back(between_tiles[1]);
    insert_data(*pPos, *pInfo, between_tiles[1][0], between_tiles[1][1], *ptrPath);


    temp_pos = {(currentX + available_tiles[1][0]) / 2, (currentY + available_tiles[1][1]) / 2};
    print_single_pixel(cols, rows, temp_pos, *ptrPath, delay);

    temp_pos = {available_tiles[1][0], available_tiles[1][1]};
    print_single_pixel(cols, rows, temp_pos, *ptrPath, delay);


    last_intersection[2] = available_tiles[1][0];
    last_intersection[3] = available_tiles[1][1];

    new_tile(available_tiles[1][0], available_tiles[1][1]);
    break;

  case 2:
    path_list.push_back(available_tiles[2]);
    path_list.push_back(between_tiles[2]);
    insert_data(*pPos, *pInfo, between_tiles[2][0], between_tiles[2][1], *ptrPath);


    temp_pos = {(currentX + available_tiles[2][0]) / 2, (currentY + available_tiles[2][1]) / 2};
    print_single_pixel(cols, rows, temp_pos, *ptrPath, delay);

    temp_pos = {available_tiles[2][0], available_tiles[2][1]};
    print_single_pixel(cols, rows, temp_pos, *ptrPath, delay);


    last_intersection[2] = available_tiles[2][0];
    last_intersection[3] = available_tiles[2][1];

    new_tile(available_tiles[2][0], available_tiles[2][1]);
    break;

  case 4:
  std::cout << "(" << last_intersection[0] << ","  << last_intersection[1] << ")";
    dead_ends.push_back({last_intersection[2], last_intersection[3]});
    new_tile(last_intersection[0], last_intersection[1]);
    //find_new_intersection(currentX, currentY, currentX, currentY);
  case 5:
    break;
  }

  
}


int main() {
  srand (time(0));

  if (rows % 2 == 0)
  {
    rows++;
  }

  if (cols  % 2 == 0)
  {
    cols++;
  }
  
  for (int x = 0; x < rows; x++)
  {
    for (int y = 0; y < cols; y++)
    {
      if (y % 2 == 0 && x % 2 == 0)
      {
        map.push_back(*ptrPossible);
      }
      else
      {
        map.push_back(empty_tile);
      }
    }
  }

  //preparing raw map for printing
  std::pair<std::vector<std::vector<int>>, std::vector<std::string>> compiledTileMap = packageTileMap(cols, rows, map); //compiles the map into the position data and the charactar data

  *pPos = compiledTileMap.first; //sets the position data as its own variable
  *pInfo = compiledTileMap.second; //sets the info data as its own variables, the actual information that will be printed

  replace_data(*pPos, *pInfo, 0, 0, *ptrPath);

  printFrameWithBorder(cols, rows, *pPos, *pInfo, title, *ptrBorder, delay);

  new_tile(0, 0);
  

  return 0;
}
