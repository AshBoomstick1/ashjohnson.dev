#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <chrono>
#include "./../../../basicTerminalDisplay/display.hpp" //can print the gamestate
#include "./../../../errorLog/errorlog.hpp" //can log errors

#if defined(__linux__)
    #include <unistd.h>
#else
    #include <windows.h>
#endif

extern int rows; //the number of rows in the maze
extern int cols; //the number of columns in the maze

extern std::vector<std::string> map;
extern std::vector<std::vector<int>> pos_data; //x y data for printing frame
extern std::vector<std::string> info_data; //charactar data for printing frame
extern std::vector<std::vector<int>> path_list; //list of tiles (x, y) that are already a part of a path
extern std::vector<std::vector<int>> dead_ends;

extern std::vector<int> last_intersection;

const extern bool skip_some_graphics;

void find_new_intersection(int currentX, int currentY, int oldX, int oldY);
void new_tile(int currentX, int currentY);
bool search_coord_vec(const int &x, const int &y, std::vector<std::vector<int>> vec); //searches a 2d vec for an (x, y) position
bool available_tile(int x, int y); //checks if a tile is empty and not a wall

